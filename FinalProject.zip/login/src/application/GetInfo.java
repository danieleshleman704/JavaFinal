package application;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class GetInfo {
	
	//creates password in the txt file
	public static String passwordWriter(String receivedText) {
		String fileName = "out.txt";
		try {
			PrintWriter outputStream = new PrintWriter(fileName);
			outputStream.println(receivedText);
			String a = "true";
					return a;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			String a = "false";
			return a;
			
		}
		}
		
		
	}

