package application;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.util.Scanner;

import javafx.event.ActionEvent;

public class MainController {
	//imports fxml items
	@FXML
	private TextField txtUsername;
	
	@FXML
	private TextField txtPassword;
	
	@FXML
	private Label lblLabel;
	
	@FXML
	private label lblNewLabel;
	
	@FXML
	private textField txtNewPassword;
	
	@FXML
	private scatterChart grphTurbine;

	//checks password
	public void Login(ActionEvent event) throws Exception {
	String pass = txtPassword.getText();
	Scanner scanner = new Scanner("out.txt");
	
	//scans text for matching words
	while (Scanner.hasNextLine()) {
		String check = "0";
	}
		String nextToken = scanner.next();
		if (nextToken.equals(pass)) {
			pass = "check";
	}
		//if a password is found it pulls up the graph
		if (pass.equals("check")) {
			lblLable.setText("Logging In");
			
			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("/application/LoginData.fxml"));
					Scene scene = new Scene(root,400,400);
					scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
					primaryStage.setScene(scene);
					primaryStage.show();
					
				//if no match is found pulls up a password creation page	
		} else {
			lblLable.setText("Incorrect Password");
			
			Stage primaryStage = new Stage();
			Parent root = FXMLLoader.load(getClass().getResource("/NewInfo.fxml"));
					Scene scene = new Scene(root,400,400);
					scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
					primaryStage.setScene(scene);
					primaryStage.show();
		}
	}
	
	//creates a new password
	public void NewInfo(ActionEvent event)  throws Exception {
		String password = txtNewLabel.getText();
		GetInfo.passwordWriter(password);
		
		Stage primaryStage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/LoginData.fxml"));
				Scene scene = new Scene(root,400,400);
				scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
				primaryStage.setScene(scene);
				primaryStage.show();
		
		}
		
		
		
		}

